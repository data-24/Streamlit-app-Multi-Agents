# Cortex Agent Studio (single agent)

A client-ready Streamlit chat app for one Snowflake Cortex Agent —
`HEALTHCARE_DB.GOLD.HEALTHCARE_AGENT`.

**The pitch:** what a business user sees is *just the answer*. SQL, the
reasoning trace, and the raw table are all **off by default** and revealed only
through the sidebar checkboxes — while every question is still audited behind
the scenes.

## What's in the box

| File | Purpose |
|------|---------|
| `app.py` | The single-agent Studio app (polished UI + real SSE parser). |
| `.streamlit/config.toml` | Theme (teal accent, Inter font). |
| `.streamlit/secrets.toml` | Your account + shared token (fill in, keep private). |
| `requirements.txt` | Dependencies. |
| `audit_extractor.py` | **Bring your own** — your existing audit module. See below. |

## Display options (sidebar checkboxes)

- **Show the data table under answers** — the result table + a bar chart.
- **Show the agent's thinking steps** — the readable planning trace.
- **Show the SQL the agent wrote** — the exact queries.
- **🔬 Debug: show raw stream** — the raw SSE, for troubleshooting.

All default to **off** so the stakeholder view is clean. Flip them on live to
show the machinery.

## Setup

```bash
pip install -r requirements.txt
```

Fill `.streamlit/secrets.toml` with your `account`, `user` (the shared-token
owner), and `token` (a Programmatic Access Token from Snowsight →
Settings → Authentication → Programmatic access tokens).

```bash
python -m streamlit run app.py
```

## Audit logging (optional)

`app.py` imports `audit_extractor` and calls:

```python
summary = summarize_audit(raw_full)
save_audit_summary(summary, question, agent_display, role,
                   account, user, pat_token, raw_response=raw_full,
                   user_name=asked_by)
```

Keep **your existing `audit_extractor.py`** in this folder and it works
unchanged — the call signature is identical to your original app. If the file
isn't present, the app detects that, hides the "Audit row saved" step, and runs
normally (the sidebar shows a small "Audit logging off" note).

## Notes

- The response parser reads the agent's real event stream: `response.status`
  (steps), `response.tool_use` (SQL), `response.tool_result` (the `result_set`
  used to build the table without re-running the query), and
  `response.text.delta` (the final answer).
- To add a second agent later, turn `AGENT` back into a dict of agents and
  re-add a sidebar picker — the rest of the code is agent-agnostic.
