"""
Cortex Agent Studio — a client-ready chat app for a single Snowflake
Cortex Agent (HEALTHCARE_DB.GOLD.HEALTHCARE_AGENT).

What a stakeholder sees is JUST THE ANSWER — SQL, reasoning trace and raw table
are off by default and revealed only via the Display-options checkboxes. Every
question can still be audited behind the scenes.

Parses the agent's real streaming format:
  • response.status      -> readable "thinking steps"
  • response.tool_use    -> the SQL the agent runs
  • response.tool_result -> the actual data (table from result_set, no re-run)
  • response.text.delta  -> the final answer, word by word

Run:  python -m streamlit run app.py
"""

import json
import re
import streamlit as st

# Audit is optional — the app runs and looks right with or without the module.
try:
    from audit_extractor import summarize_audit, save_audit_summary
    AUDIT_AVAILABLE = True
except Exception:  # noqa: BLE001
    AUDIT_AVAILABLE = False

st.set_page_config(page_title="Healthcare Agent · Cortex Studio",
                   page_icon="🏥", layout="wide")

# --------------------------------------------------------------------------- #
# Single-agent configuration
# --------------------------------------------------------------------------- #
AGENT = {
    "display": "Healthcare Agent",
    "emoji": "🏥",
    "db": "HEALTHCARE_DB",
    "schema": "GOLD",
    "name": "HEALTHCARE_AGENT",
    "tagline": "Ask about patients, conditions, admissions, medications, test results, insurance and billing — in plain English.",
}

# Landing stat tiles (facts about the loaded dataset).
STATS = [
    ("55,500", "Patient records"),
    ("6", "Medical conditions"),
    ("5", "Insurance providers"),
    ("2019–2024", "Admission years"),
]

# Example questions, each with a small category icon.
EXAMPLES = [
    ("🩺", "How many patients are there for each medical condition?"),
    ("💳", "What is the average billing amount by insurance provider?"),
    ("🏥", "Which 10 hospitals have the highest total billing?"),
    ("📅", "How many admissions were there each year?"),
    ("🚑", "Compare average billing for Emergency, Urgent and Elective admissions."),
    ("⚕️", "What is the gender breakdown of cancer patients?"),
    ("💊", "Which medications are most common for Diabetes patients?"),
    ("🧪", "What share of test results are Abnormal, Normal or Inconclusive?"),
    ("📊", "What is the average patient age for each medical condition?"),
]

# Brand + chart tokens (aqua single-hue, validated palette ink/grid).
TEAL_A, TEAL_B = "#0e7c86", "#14b8a6"
BAR_HUE   = "#1baf7a"   # single validated hue for one-series bars
INK       = "#0b0b0b"
INK_SOFT  = "#52514e"
MUTED     = "#898781"
GRID      = "#e7e6e0"
AXIS      = "#c3c2b7"

# --------------------------------------------------------------------------- #
# Styling
# --------------------------------------------------------------------------- #
st.markdown(
    f"""
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');

      html, body, [class*="css"] {{ font-family:'Inter', system-ui, sans-serif; }}
      .stApp {{ background:#f6f8fa; }}
      .block-container {{ padding-top:1.4rem; padding-bottom:2rem; max-width:1080px; }}

      /* ---------- Hero ---------- */
      .hero {{
        position:relative; overflow:hidden;
        background:linear-gradient(135deg, {TEAL_A} 0%, {TEAL_B} 100%);
        border-radius:24px; padding:30px 34px; color:#fff;
        box-shadow:0 18px 40px rgba(14,124,134,.28);
      }}
      .hero::after {{  /* subtle heartbeat motif */
        content:""; position:absolute; right:-40px; top:-40px; width:280px; height:280px;
        background:radial-gradient(circle at center, rgba(255,255,255,.16), transparent 60%);
      }}
      .hero-row {{ display:flex; align-items:center; gap:22px; position:relative; z-index:1; }}
      .hero-badge {{ width:74px; height:74px; border-radius:20px; background:rgba(255,255,255,.16);
        border:1px solid rgba(255,255,255,.30); display:flex; align-items:center;
        justify-content:center; font-size:40px; flex:none;
        box-shadow:0 6px 18px rgba(0,0,0,.14); }}
      .hero-eyebrow {{ text-transform:uppercase; letter-spacing:2px; font-size:11.5px;
        font-weight:700; opacity:.85; margin-bottom:2px; }}
      .hero-title {{ font-size:34px; font-weight:900; letter-spacing:-.7px; line-height:1.05; }}
      .hero-sub {{ font-size:15px; opacity:.95; margin-top:7px; max-width:640px; line-height:1.5; }}
      .chip {{ display:inline-flex; align-items:center; gap:6px; margin-top:14px; margin-right:8px;
        padding:5px 13px; background:rgba(255,255,255,.20); border:1px solid rgba(255,255,255,.30);
        border-radius:999px; font-size:12.5px; font-weight:600; }}

      /* ---------- Stat tiles ---------- */
      .stat {{ background:#fff; border:1px solid #eceef1; border-radius:16px;
        padding:16px 18px; box-shadow:0 2px 10px rgba(16,50,79,.05); height:100%; }}
      .stat .v {{ font-size:26px; font-weight:800; color:{TEAL_A}; letter-spacing:-.5px; }}
      .stat .l {{ font-size:12.5px; font-weight:600; color:{MUTED}; margin-top:2px; text-transform:uppercase; letter-spacing:.4px; }}

      /* ---------- Section label ---------- */
      .hint {{ color:{INK_SOFT}; font-size:13.5px; font-weight:700; letter-spacing:.2px;
        margin:22px 2px 10px; text-transform:uppercase; }}

      /* ---------- Example question cards ---------- */
      div[data-testid="stButton"] > button {{
        border-radius:14px; border:1px solid #e7eaee; background:#ffffff;
        color:{INK}; font-size:14px; font-weight:500; line-height:1.4; text-align:left;
        min-height:78px; padding:14px 16px; transition:all .16s ease;
        box-shadow:0 1px 3px rgba(15,23,42,.05); white-space:normal;
      }}
      div[data-testid="stButton"] > button:hover {{
        border-color:{TEAL_B}; background:#f4fbfa; color:{TEAL_A};
        box-shadow:0 10px 22px rgba(20,184,166,.16); transform:translateY(-2px);
      }}
      div[data-testid="stButton"] > button:active {{ transform:translateY(0); }}

      /* Sidebar Clear button (secondary) */
      section[data-testid="stSidebar"] div[data-testid="stButton"] > button {{
        min-height:0; text-align:center; font-weight:600; }}

      /* ---------- Chat ---------- */
      div[data-testid="stChatMessage"] {{
        background:#ffffff; border:1px solid #edeff2; border-radius:16px;
        padding:14px 16px; box-shadow:0 2px 10px rgba(16,50,79,.04); margin-bottom:12px; }}
      div[data-testid="stChatMessage"] p {{ font-size:15.5px; line-height:1.6; color:{INK}; }}

      /* ---------- Sidebar ---------- */
      section[data-testid="stSidebar"] {{ background:#ffffff; border-right:1px solid #eef1f4; }}
      section[data-testid="stSidebar"] .brand {{ font-size:17px; font-weight:800; color:{INK};
        display:flex; align-items:center; gap:8px; }}
      section[data-testid="stSidebar"] h4 {{ font-weight:700; color:{INK_SOFT};
        font-size:12.5px; text-transform:uppercase; letter-spacing:.5px; margin-bottom:4px; }}

      /* ---------- Footer ---------- */
      .footer {{ margin-top:34px; padding-top:16px; border-top:1px solid #e9ecef;
        display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; }}
      .footer .tags span {{ display:inline-block; margin-right:6px; margin-bottom:6px;
        padding:4px 11px; border-radius:999px; background:#edf6f6; color:{TEAL_A};
        font-size:12px; font-weight:600; border:1px solid #d7ebed; }}
      .footer .by {{ color:{MUTED}; font-size:13px; font-weight:600; }}

      #MainMenu, header {{ visibility:hidden; }}
    </style>
    """,
    unsafe_allow_html=True,
)

# --------------------------------------------------------------------------- #
# Sidebar
# --------------------------------------------------------------------------- #
with st.sidebar:
    st.markdown('<div class="brand">❄️ Cortex Agent Studio</div>', unsafe_allow_html=True)
    st.caption("Ask the agent a question in plain English.")
    st.markdown("")

    st.markdown("#### 🎭 Your role")
    role = st.selectbox("Run as role", ["ACCOUNTADMIN", "READER_ROLE"],
                        label_visibility="collapsed")

    st.markdown("#### 🙋 Your name")
    asked_by = st.selectbox("Your name", ["PRIYANKA", "ANAND_JHA"],
                            label_visibility="collapsed",
                            help="Who is asking — saved in the audit table.")

    account = st.secrets.get("snowflake", {}).get("account", "")
    user = st.secrets.get("snowflake", {}).get("user", "")
    pat_token = st.secrets.get("snowflake", {}).get("token", "")

    with st.expander("⚙️ Display options", expanded=True):
        show_numbers = st.checkbox("Show the data table under answers", value=False)
        show_thinking = st.checkbox("Show the agent's thinking steps", value=False,
                                    help="The agent's planning trace.")
        show_sql = st.checkbox("Show the SQL the agent wrote", value=False)
        show_debug = st.checkbox("🔬 Debug: show raw stream", value=False)

    st.divider()
    if st.button("🗑️  Clear conversation", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

    if not account or not pat_token:
        st.error("Add `account` and `token` to .streamlit/secrets.toml")
    if not AUDIT_AVAILABLE:
        st.caption("ℹ️ Audit logging off (audit_extractor.py not found).")

BASE_URL = f"https://{account}.snowflakecomputing.com"


# --------------------------------------------------------------------------- #
# Agent call — parses the agent's real streaming format
# --------------------------------------------------------------------------- #
def ask_agent(question: str) -> dict:
    import requests
    url = (f"{BASE_URL}/api/v2/databases/{AGENT['db']}"
           f"/schemas/{AGENT['schema']}/agents/{AGENT['name']}:run")
    headers = {
        "Authorization": f"Bearer {pat_token}",
        "X-Snowflake-Authorization-Token-Type": "PROGRAMMATIC_ACCESS_TOKEN",
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
    }
    body = {"messages": [{"role": "user",
                          "content": [{"type": "text", "text": question}]}]}
    resp = requests.post(url, headers=headers, json=body, stream=True, timeout=120)
    if resp.status_code != 200:
        return {"text": f"⚠️ Sorry, I couldn't reach the agent (error {resp.status_code}).",
                "thinking_steps": [], "sql_queries": [], "table": None,
                "debug": resp.text[:400], "raw_full": ""}

    current_event = None
    answer_parts, final_full = [], ""
    steps, sql_queries, table = [], [], None
    debug_lines, raw_all = [], []

    for raw in resp.iter_lines():
        if raw is None:
            continue
        line = raw.decode("utf-8")
        if line.strip():
            raw_all.append(line)
            if len(debug_lines) < 200:
                debug_lines.append(line[:400])
        if line.startswith("event:"):
            current_event = line[len("event:"):].strip().lower()
            continue
        if not line.startswith("data:"):
            continue
        payload = line[len("data:"):].strip()
        if payload in ("[DONE]", ""):
            continue
        try:
            obj = json.loads(payload)
        except json.JSONDecodeError:
            continue
        ev = current_event or ""

        if ev == "response.text.delta":
            t = obj.get("text")
            if isinstance(t, str):
                answer_parts.append(t)
            continue
        if ev == "response.text":
            t = obj.get("text")
            if isinstance(t, str):
                final_full = t
            continue
        if ev == "response.status":
            msg = obj.get("message")
            if isinstance(msg, str) and msg and (not steps or steps[-1] != msg):
                steps.append(msg)
            continue
        if ev == "response.tool_use":
            desc = _describe_tool(obj)
            if desc and (not steps or steps[-1] != desc):
                steps.append(desc)
            sql = (obj.get("input") or {}).get("sql")
            if isinstance(sql, str) and sql.strip():
                clean = sql.strip().rstrip(";")
                if clean not in sql_queries:
                    sql_queries.append(clean)
            continue
        if ev == "response.tool_result":
            tbl = _extract_table(obj)
            if tbl:
                table = tbl
            continue

    answer = _tidy("".join(answer_parts).strip() or final_full.strip())
    return {"text": answer or "_(I didn't get a text answer back — please rephrase.)_",
            "thinking_steps": steps, "sql_queries": sql_queries,
            "table": table, "debug": "\n".join(debug_lines),
            "raw_full": "\n".join(raw_all)}


def _tidy(text: str) -> str:
    """Insert a space where the agent glues a sentence end to the next capital."""
    if not text:
        return text
    return re.sub(r'([.!?,])([A-Z])', r'\1 \2', text)


def _describe_tool(obj) -> str:
    inp = obj.get("input") or {}
    sql = inp.get("sql")
    if isinstance(sql, str) and sql.strip():
        one = " ".join(sql.split())
        if len(one) > 160:
            one = one[:160] + " …"
        return "🗄️ Ran a query — " + one
    pq = inp.get("pruning_question")
    if isinstance(pq, str) and pq.strip():
        return "🔎 Looked up the data model for: " + pq
    return "🔧 Used " + (obj.get("name") or "a tool")


def _extract_table(obj):
    content = obj.get("content")
    if not isinstance(content, list):
        return None
    for item in content:
        j = item.get("json") if isinstance(item, dict) else None
        rs = j.get("result_set") if isinstance(j, dict) else None
        if not isinstance(rs, dict):
            continue
        meta = rs.get("resultSetMetaData") or {}
        cols = [c.get("name") for c in (meta.get("rowType") or []) if isinstance(c, dict)]
        data = rs.get("data")
        if cols and isinstance(data, list) and data:
            rows = [[_num(v) for v in r] for r in data]
            return {"columns": cols, "rows": rows}
    return None


def _num(v):
    if isinstance(v, str):
        s = v.strip()
        if s == "":
            return v
        try:
            f = float(s)
            return int(f) if f.is_integer() else f
        except ValueError:
            return v
    return v


def _render_steps(steps):
    for i, s in enumerate(steps, 1):
        st.markdown(f"✅ **Step {i}** — {s}")


def _render_sql(queries):
    for i, q in enumerate(queries, 1):
        if len(queries) > 1:
            st.caption(f"Query {i}")
        st.code(q, language="sql")


def render_table(table):
    """Styled data table + a single-hue branded bar chart (Altair)."""
    import pandas as pd
    import altair as alt

    df = pd.DataFrame(table["rows"], columns=table["columns"])
    if df.empty:
        return
    pretty = {c: c.replace("_", " ").title() for c in df.columns}
    dfp = df.rename(columns=pretty)

    with st.expander("📊 See the data", expanded=True):
        st.dataframe(dfp, use_container_width=True, hide_index=True)

        label_col = next((c for c in df.columns
                          if not pd.api.types.is_numeric_dtype(df[c])), None)
        value_col = next((c for c in df.columns
                          if pd.api.types.is_numeric_dtype(df[c])), None)
        if label_col and value_col and 1 < len(df) <= 25:
            lc, vc = pretty[label_col], pretty[value_col]
            chart = (
                alt.Chart(dfp)
                .mark_bar(color=BAR_HUE, cornerRadiusEnd=4, size=20)
                .encode(
                    x=alt.X(f"{vc}:Q", title=None,
                            axis=alt.Axis(grid=True, gridColor=GRID, gridWidth=1,
                                          labelColor=MUTED, tickColor=AXIS,
                                          domainColor=AXIS, labelFontSize=12)),
                    y=alt.Y(f"{lc}:N", sort="-x", title=None,
                            axis=alt.Axis(labelColor=INK_SOFT, tickColor=AXIS,
                                          domainColor=AXIS, labelFontSize=13,
                                          labelLimit=220)),
                    tooltip=[alt.Tooltip(f"{lc}:N"), alt.Tooltip(f"{vc}:Q", format=",")],
                )
                .properties(height=min(len(df) * 42 + 30, 480))
                .configure_view(strokeWidth=0)
                .configure_axis(labelFont="Inter", titleFont="Inter")
            )
            st.altair_chart(chart, use_container_width=True)


# --------------------------------------------------------------------------- #
# Hero
# --------------------------------------------------------------------------- #
st.markdown(
    f"""
    <div class="hero">
      <div class="hero-row">
        <div class="hero-badge">{AGENT['emoji']}</div>
        <div>
          <div class="hero-eyebrow">Snowflake Cortex · Hospital Analytics</div>
          <div class="hero-title">{AGENT['display']}</div>
          <div class="hero-sub">{AGENT['tagline']}</div>
          <span class="chip">🎭 Role: {role}</span>
          <span class="chip">🙋 {asked_by}</span>
          <span class="chip">🔒 Governed by RBAC + PAT</span>
        </div>
      </div>
    </div>
    """,
    unsafe_allow_html=True,
)

if "messages" not in st.session_state:
    st.session_state.messages = []

is_landing = len(st.session_state.messages) == 0

# --------------------------------------------------------------------------- #
# Landing: stat tiles + example cards
# --------------------------------------------------------------------------- #
clicked_example = None

if is_landing:
    st.markdown("")
    scols = st.columns(len(STATS))
    for col, (v, l) in zip(scols, STATS):
        col.markdown(f'<div class="stat"><div class="v">{v}</div>'
                     f'<div class="l">{l}</div></div>', unsafe_allow_html=True)

st.markdown('<div class="hint">💡 Try asking</div>', unsafe_allow_html=True)
PER_ROW = 3
for start in range(0, len(EXAMPLES), PER_ROW):
    cols = st.columns(PER_ROW)
    for j, (icon, q) in enumerate(EXAMPLES[start:start + PER_ROW]):
        if cols[j].button(f"{icon}  {q}", key=f"ex_{start + j}", use_container_width=True):
            clicked_example = q

st.divider()

# --------------------------------------------------------------------------- #
# Chat history
# --------------------------------------------------------------------------- #
USER_AV, BOT_AV = "🧑‍⚕️", "🏥"
for m in st.session_state.messages:
    with st.chat_message(m["role"], avatar=USER_AV if m["role"] == "user" else BOT_AV):
        st.markdown(m["content"])
        if show_thinking and m.get("thinking_steps"):
            with st.expander("🧠 Thinking steps", expanded=True):
                _render_steps(m["thinking_steps"])
        if show_sql and m.get("sql_queries"):
            with st.expander("🧩 SQL the agent used", expanded=True):
                _render_sql(m["sql_queries"])
        if show_numbers and m.get("table"):
            render_table(m["table"])
        if show_debug and m.get("debug"):
            with st.expander("🔬 Raw stream (debug)", expanded=False):
                st.code(m["debug"])

# --------------------------------------------------------------------------- #
# New turn
# --------------------------------------------------------------------------- #
typed = st.chat_input(f"Ask the {AGENT['display']} anything…")
question = typed or clicked_example

if question:
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user", avatar=USER_AV):
        st.markdown(question)

    with st.chat_message("assistant", avatar=BOT_AV):
        steps, sql_queries, table, debug, raw_full = [], [], None, "", ""
        if not pat_token:
            answer = "⚠️ Add your access token to `.streamlit/secrets.toml` first."
        else:
            with st.spinner(f"{AGENT['display']} is thinking…"):
                try:
                    result = ask_agent(question)
                    answer = result["text"]
                    steps = result.get("thinking_steps", [])
                    sql_queries = result.get("sql_queries", [])
                    table = result.get("table")
                    debug = result.get("debug", "")
                    raw_full = result.get("raw_full", "")
                except Exception as e:  # noqa: BLE001
                    answer = f"⚠️ Something went wrong: {e}"

        st.markdown(answer)

        if show_thinking and steps:
            with st.expander("🧠 Thinking steps", expanded=True):
                _render_steps(steps)
        if show_sql and sql_queries:
            with st.expander("🧩 SQL the agent used", expanded=True):
                _render_sql(sql_queries)
        if show_numbers and table:
            render_table(table)
        if show_debug and debug:
            with st.expander("🔬 Raw stream (debug)", expanded=False):
                st.code(debug)

        if AUDIT_AVAILABLE and pat_token and raw_full:
            try:
                summary = summarize_audit(raw_full)
                save_audit_summary(summary, question, AGENT["display"], role,
                                   account, user, pat_token, raw_response=raw_full,
                                   user_name=asked_by)
                st.success("✅ Audit row saved.")
            except Exception as e:  # noqa: BLE001
                st.error(f"⚠️ Audit save failed: {e}")

    msg = {"role": "assistant", "content": answer}
    if steps:
        msg["thinking_steps"] = steps
    if sql_queries:
        msg["sql_queries"] = sql_queries
    if table:
        msg["table"] = table
    if debug:
        msg["debug"] = debug
    st.session_state.messages.append(msg)
    st.rerun()

# --------------------------------------------------------------------------- #
# Footer
# --------------------------------------------------------------------------- #
st.markdown(
    """
    <div class="footer">
      <div class="tags">
        <span>Snowflake Cortex Agents</span><span>Cortex REST API</span>
        <span>Streamlit</span><span>Python</span><span>RBAC + PAT</span>
      </div>
      <div class="by">Built by Priyanka Pandey</div>
    </div>
    """,
    unsafe_allow_html=True,
)